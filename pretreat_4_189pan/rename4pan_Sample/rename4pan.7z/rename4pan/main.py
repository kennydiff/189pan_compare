# This is a sample Python script.

# Press ⌃R to execute it or replace it with your code.
# Press Double ⇧ to search everywhere for classes, files, tool windows, actions, and settings.


import os


def dealShitName(ShitName):
    while '  ' in ShitName:  # Python 太TM简洁了啊，，，这段简直优雅得不行了
        ShitName = ShitName.replace('  ', ' ')
    GoodName = ShitName.replace(' ', '.').replace('\'', '`')
    return GoodName


# rename file name 的代码段
# old_file_name = "./Don't    Cool     Sample.srt"
old_file_name = "./Kenny's  B  Cool       Sample.srt"

print(old_file_name)
print(dealShitName(old_file_name))
print(os.path.isfile(old_file_name))

for dirpath, dirnames, filenames in os.walk('.'):
    for dirname in dirnames:
        print(os.path.join(dirpath, dirname))
        os.rename(old_file_name, new_file_name)

print("---- 以上是目录，以下是文件 -----------------------")

for dirpath, dirnames, filenames in os.walk('.'):
    for filename in filenames:
        print(os.path.join(dirpath, filename))


# new_file_name = "./testLog.log2"
# os.rename(old_file_name, new_file_name)
# print("File renamed!")
